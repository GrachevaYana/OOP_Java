package HW_3.record;

import java.util.List;

public interface RecordService {

    List<Record> getRecords();

}
