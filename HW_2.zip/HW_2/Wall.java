package HW_2;

public class Wall {
    private int Height;

    public Wall(int height) {
       this.Height = height;
    }

    public int getHeight() { return Height; }

    public void setHeight(int height) { Height = height; }
}
