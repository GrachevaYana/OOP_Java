package HW_2;

public class Treadmill {
    private int range;

    public Treadmill(int range) {
        this.range = range;
    }

    public int getRange() {
        return range;
    }

    public void setRange(int range) { this.range = range; }
}
